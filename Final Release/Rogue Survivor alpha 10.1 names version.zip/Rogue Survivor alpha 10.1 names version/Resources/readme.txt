﻿Looking at the resources files will spoil the game for you.
Mod the files at your own risks.
